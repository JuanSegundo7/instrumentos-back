module.exports = {
  "development": {
    "username": "root",
    "password": "12345",
    "database": "instrumentos",
    "host": "127.0.0.1",
    "dialect": "mysql",
    "port": 3306
  },
  "test": {
    "username": "ci632ujgi67fdosq",
    "password": "mkq737kvlmsguhqx",
    "database": "qpc83dozuwrkw637",
    "host": "y6aj3qju8efqj0w1.cbetxkdyhwsb.us-east-1.rds.amazonaws.com",
    "dialect": "mysql"
  },
  "production": {
    "username": "ci632ujgi67fdosq",
    "password": "mkq737kvlmsguhqx",
    "database": "qpc83dozuwrkw637",
    "host": "y6aj3qju8efqj0w1.cbetxkdyhwsb.us-east-1.rds.amazonaws.com",
    "dialect": "mysql"
  }
}
